package com.example.ssunapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegActivity extends AppCompatActivity {

    EditText reg_username, reg_mail, reg_pass;
    DataBase dbsqlite;
    Button signup;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_reg);

        dbsqlite = new DataBase(this);
        reg_username = findViewById(R.id.reg_et_name);
        reg_mail = findViewById(R.id.reg_et_mail);
        reg_pass = findViewById(R.id.reg_et_pass);
        signup = findViewById(R.id.reg_btn_signup);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String user_name=reg_username.getText().toString();

                String user_mail=reg_mail.getText().toString();
                String user_pass=reg_pass.getText().toString();
                if(user_name.isEmpty() || user_mail.isEmpty() || user_pass.isEmpty()){
                    Toast.makeText(getApplicationContext(), "User name field is empty, try Again", Toast.LENGTH_SHORT).show();
                }else{
                    User record=new User(user_name,user_mail,user_pass);

                    boolean res=dbsqlite.Insert_user(record);
                    if (res){

                        Toast.makeText(getApplicationContext(), "insert Successful", Toast.LENGTH_SHORT).show();

                        Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
                        startActivity(intent);

                    }else {
                        Toast.makeText(getApplicationContext(), "Invalid username or password", Toast.LENGTH_SHORT).show();
                    }
                }


            }
        });


    }

}