package com.example.ssunapp;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;
import android.view.Menu;
import android.view.MenuItem;
import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.SearchView;
import androidx.appcompat.widget.Toolbar;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private Toolbar toolbar;
    private RecyclerView recyclerView;
    private FloatingActionButton addButton;
    private NotaterRcvAdapter notaterRcvAdapter;
    private SwipeRefreshLayout swipeRefreshLayout;
    private DataBase sqlite;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        initializeViews();
        setupToolbar();
        setupRecyclerView();
        setupAddButton();
    }

    private void initializeViews() {
        toolbar = findViewById(R.id.main_activ_toolbar);
        recyclerView = findViewById(R.id.main_activ_rsv);
        addButton = findViewById(R.id.main_activ_fbut_addnot);
        swipeRefreshLayout = findViewById(R.id.swipeRefreshLayout);

        swipeRefreshLayout.setOnRefreshListener(this::refreshNotater);
    }

    private void setupToolbar() {
        Toolbar toolbar = findViewById(R.id.main_activ_toolbar);
        setSupportActionBar(toolbar);
    }

    private void setupRecyclerView() {
        sqlite = new DataBase(this);
        ArrayList<Noter> noters = sqlite.getAllnoters();
        notaterRcvAdapter = new NotaterRcvAdapter(noters, this);
        recyclerView.setLayoutManager(new GridLayoutManager(this, 2));
        recyclerView.setAdapter(notaterRcvAdapter);
        recyclerView.setHasFixedSize(true);
    }

    private void setupAddButton() {
        addButton.setOnClickListener(view -> {
            Intent intent = new Intent(getApplicationContext(), ViewNotActivity.class);
            startActivity(intent);
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshNotater();
    }

    private void refreshNotater() {
        ArrayList<Noter> updatedNoters = sqlite.getAllnoters();
        notaterRcvAdapter.filter(""); // Reset the adapter with updated data
        swipeRefreshLayout.setRefreshing(false);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.main_meny, menu);

        // Find the search item
        MenuItem searchItem = menu.findItem(R.id.app_bar_search);
        if (searchItem != null) {
            SearchView searchView = (SearchView) searchItem.getActionView();
            if (searchView != null) {
                // Set the listener for the SearchView
                searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
                    @Override
                    public boolean onQueryTextSubmit(String query) {
                        // Add your search logic here
                        notaterRcvAdapter.filter(query);
                        return true;
                    }

                    @Override
                    public boolean onQueryTextChange(String newText) {
                        // Update the search filter as the user types
                        notaterRcvAdapter.filter(newText);
                        return true;
                    }
                });
            } else {
                Toast.makeText(MainActivity.this, "Search View is not found", Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(MainActivity.this, "Search item is not found in the menu", Toast.LENGTH_SHORT).show();
        }

        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.details_meny_lagre:
                // Handle save action
                return true;
            case R.id.details_meny_rediger:
                // Handle edit action
                return true;
            case R.id.details_meny_slett:
                // Handle delete action
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
